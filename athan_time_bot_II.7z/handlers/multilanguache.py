


def uzbekl ():

def uzbekc():

def ru(ckur5,cfui):
    #hello is reg
    # ckur5 => check_user[5] in main fail
    HIR = "В настройках пользователя выбран язык: {ckur5}  \
                              Уже зарегестрированный пользователь может видеть тут что угодно.\
                              Я пока оставил кнопку послать метаданные ХОТЯ они уже есть в базе \
                              можно просто кнопку чтоб показать времена азанов кстати можно календарь\
                               на месяц вперед"  
    #user select russian lang
    cfui=> callback.from_user.id
    USRL = "({cfui}) Вы выбрали русский язык"